//
//  ViewController.swift
//  random
//
//  Created by Spur IQ on 6/18/19.
//  Copyright © 2019 Debesh. All rights reserved.
//

import UIKit

class ViewController: UIViewController{
    
    
    var images : [String] = ["Bear", "Pikachu", "Rubix","Eevie", "Robot",
                 "Psyduck","Book","Science","Test"]

    @IBAction func buttonClick(_ sender: Any) {
    }
    @IBOutlet weak var image1: UIImageView!
    @IBOutlet weak var image2: UIImageView!



}


