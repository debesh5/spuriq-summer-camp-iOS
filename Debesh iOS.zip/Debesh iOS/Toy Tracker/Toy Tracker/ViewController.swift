//
//  ViewController.swift
//  Toy Tracker
//
//  Created by Spur IQ on 6/18/19.
//  Copyright © 2019 Debesh. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

