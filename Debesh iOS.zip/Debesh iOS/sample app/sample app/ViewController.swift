
import UIKit

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate{
    
    var toys : [String] = []
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
     return toys.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell1=UITableViewCell(style: .default, reuseIdentifier: "cellID")
        cell1.textLabel?.text = toys[indexPath.row]
        return cell1
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
    
        if (editingStyle == UITableViewCell.EditingStyle.delete){
            toys.remove(at: indexPath.row)
            TableView.reloadData()
            writeDataToFile()
        }
    }
    
    @IBAction func AddAToy(_ sender: Any) {
        if(textBox.text != ""){
            toys.append(textBox.text!)
            TableView.reloadData()
            writeDataToFile()
            textBox.text=""
        }
    }
    
    @IBOutlet weak var textBox: UITextField!
    @IBOutlet weak var TableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        readDataFromFile()
        
    }
    let strFileName = "spurIQArray.txt"
    let dir = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first
    
    func readDataFromFile(){
        
        let fileURL = dir?.appendingPathComponent(strFileName)
    
        let fileManager = FileManager.default
        let pathComponent = dir!.appendingPathComponent(strFileName)
        let filePath = pathComponent.path

 
        if fileManager.fileExists(atPath: filePath){
            toys  = NSMutableArray(contentsOf: fileURL!) as! [String]
        }
        else
        {
            writeDataToFile()
        }
    }
func writeDataToFile()
{
    let fileURL = dir?.appendingPathComponent(strFileName)
    (toys as NSArray).write(to: fileURL!,atomically:true)
}
}
